---
name: luma-take-home-session-gotchas
description: "Harness and repo pitfalls learned on 2026-09-05 (chained PRs, plan-file collisions, hidden browser pane, another session editing the tree)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bf41d799-a0a5-4544-96d0-c30f0c1b924c
  modified: 2026-09-05T21:05:00.730Z
---

Pitfalls from the 2026-09-05 sessions on the Luma take-home:

- **Chained PRs strand work.** PRs based on another task branch (#15 on task/15, #17 on task/16) were merged into their bases *after* those bases had been merged to main, so main never got them. Open every PR against `main` (rebase the chain first), or merge the chain in reverse order.
- **Check the plan filename before writing.** `docs/superpowers/plans/2026-09-05-review-flow.md` already existed (Task 12); a new plan overwrote it and had to be restored from git.
- **Another session works in the same tree.** APPROACH.md was rewritten uncommitted by a parallel session; leave it alone, stash it around branch switches, never commit it from this session.
- **The Browser pane can be hidden**: `document.hidden` is true, animation frames stall, transitions sit at time 0 and computed opacity reads 0. Verify motion via `getAnimations()`, compiled CSS rules and screenshots (which force a frame), not computed values.
- **Tailwind v4 + nested `@starting-style`**: the compiler flattens a nested `@starting-style` into the parent rule; write it at top level. Unlayered rules in globals.css beat utilities (`animate-spin` was overridden by a custom `animation`).
- **ESLint flat-config `files` globs**: `[sku]` reads as a character class; use `app/review/*/page.tsx`.

**Why:** each cost a round trip or lost work once.
**How to apply:** check `git merge-base --is-ancestor <sha> main` after the user says "merged"; `ls docs/superpowers/plans` before naming a plan; see [[luma-take-home-resume]] and [[bash-heredoc-backslash-gotcha]].

- **Worktrees (2026-09-06):** `npm install` in a fresh worktree fails (better-sqlite3 has no
  prebuild for the local Node 26, no Visual Studio). Junction `node_modules` to the main
  checkout instead: `cmd //c "mklink /J node_modules <main>\node_modules"`. Preview a
  worktree by adding a second `.claude/launch.json` config in the main checkout that
  `Set-Location`s into the worktree and runs `npx next dev -p 3001` with `APP_URL`
  pointing at 3001 and `DATA_DIR` at the main checkout's `data-local`.
- **Evaluator mutations:** tell the evaluator never to `git checkout -- <file>` or stash in
  a worktree whose HEAD equals main; round 1 of Task 20 wiped three task files that way
  (it restored them). A dev server running meanwhile shows the reverted code.
