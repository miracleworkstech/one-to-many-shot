---
name: bash-heredoc-backslash-gotcha
description: The Bash tool collapses backslashes inside heredocs and node -e strings; python3 is not installed on this machine
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 13111790-d011-4743-a100-de76fa0e21ad
  modified: 2026-09-05T21:36:30.472Z
---

Two tool gotchas on this Windows box, both hit more than once:

1. A `\` inside a Bash heredoc or a `node -e "..."` string gets collapsed, so `"\\n"` lands in
   the file as a literal newline and breaks the syntax (a silent Prettier failure, then a
   commit without the change). `python3` is also not installed: a `python3 - <<EOF` block
   prints a Store hint and does nothing, and the rest of the chained command still runs.

**Why:** Both fail quietly. In one session the STATE.md update was skipped and the commit
went in without it; in another a worker.ts edit shipped with an unterminated string.

**How to apply:** Use the Edit or Write tool for any content with a backslash or a regex.
Use `node -e` (not python) for scripted file edits, and grep the result before the
`npm run check` and the commit. Related: [[luma-take-home-session-gotchas]].
