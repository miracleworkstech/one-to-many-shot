---
name: luma-take-home-codex-third-check
description: "Every Luma take-home task runs a Codex review as the third check, only after the Claude evaluator PASSes, before the PR"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c28003d5-8447-4dc6-ae48-2087a3c9a43f
  modified: 2026-09-03T23:59:09.163Z
---

On the Luma take-home, each task has three gated checks in order: (1) implementer's
`npm run check`, (2) Claude evaluator (project skill `evaluating-task`) must PASS,
(3) Codex review of the task diff via the `codex:codex-rescue` subagent, read-only. Codex
runs after the evaluator, never in parallel. Cheap Codex findings get fixed on the branch
and re-checked; product-decision findings go to the user verbatim in the PR and the recap.
Only then open the PR. Codex is part of validation, not of the user's review: it must be
finished before the user sees the PR, and the user's review is the last gate before merge.
Recorded as the 2026-09-04 amendment to D8 in DECISIONS.md.

**Why:** The user asked for it on 2026-09-04 after Task 3: they had not seen Codex output
and wanted it as a final independent pass per task, not only once after Task 8. On Task 3
Codex found two real gaps the evaluator missed (an uncapped paid Haiku path, a `suggested`
count that reported proposals rather than rows written).

**How to apply:** Don't open a PR without the Codex step. Don't run Codex while `next dev`
is up (its sandbox rebuilds `.next` and the dev server 500s). Do the manual browser check
before or after Codex. Relay Codex's findings verbatim to the user. See
[[luma-take-home-resume]] and [[luma-take-home-working-style]].

**Status 2026-09-06:** the user updated Codex CLI to 0.153.4. The account's default model
(`gpt-6-astra`) still says it needs a newer CLI; the rescue subagent falls back to
`gpt-5.3-codex-spark`, which works. `codex exec -m gpt-5.4` is refused for ChatGPT accounts.
If Codex fails outright, check `codex --version` and ask the user to update rather than
retrying models.
