---
name: luma-take-home-resume
description: How to resume the Luma FDE take-home; where the task board, harness and next action live
metadata:
  type: project
---

Read `CLAUDE.md` then `docs/STATE.md` first; STATE holds the task board, last commit per task,
environment facts and the next action. Plan with checkboxes:
`docs/superpowers/plans/2026-09-03-styled-shots.md`. Harness artifacts (briefs, reports, evals,
diff patches, progress ledger) live in `.superpowers/sdd/` (gitignored).

As of 2026-09-04: Tasks 1 to 7 merged; Task 8 (gate, Docker, Railway) is PR #7 on
`task/8-deploy`, awaiting the user's review. Still owed after approval: whole-diff Codex pass,
the Railway deploy with the user (volume, secrets in the dashboard, domain, `APP_URL`), Task 9
(docs, video). Luma credits were zero and the Slack webhook was not yet created.

**How to apply:** Never start the next task or merge without the user's go. Subagent
`SendMessage` is disabled in this environment, so fixes go to a fresh agent with the report
path. See [[luma-take-home-working-style]] and [[luma-take-home-codex-third-check]].
