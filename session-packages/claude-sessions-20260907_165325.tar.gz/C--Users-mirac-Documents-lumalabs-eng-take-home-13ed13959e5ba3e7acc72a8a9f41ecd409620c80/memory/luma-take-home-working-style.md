---
name: luma-take-home-working-style
description: "How Miracle wants to work on the Luma take-home: options with trade-offs, they decide; push back plainly; money-path failure modes before code; SRP; typed unions over strings"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 60072571-23f6-46b4-84f8-ac4534be68f8
  modified: 2026-09-03T20:39:01.340Z
---

Miracle owns decisions and wants Claude to own mechanics. Present two or three options with
trade-offs and a recommendation, then wait. Push back plainly when they are wrong. For money
paths (budget, generation triggers, approvals) walk through failure modes and races before
writing code. Refactor when a module grows a second responsibility. No stringly-typed
states: unions from const arrays, mirrored as DB CHECK constraints and typed SQL helpers.

**Why:** Reviewers read the whole session; the working style is part of the deliverable.
Miracle caught `{ state: string }` and failures hiding in `needs_more` on plan review, and
asked for the evaluator to mutation-test rather than read tests.

**How to apply:** Log every material choice in DECISIONS.md (Decision / Alternatives / Why /
Cost / Revisit trigger). Keep ASSUMPTIONS.md for brief-silent assumptions only. Never read
or print `.env.local`. Small commits with reasoned messages. See [[luma-take-home-resume]].
