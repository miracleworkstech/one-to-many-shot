---
name: luma-take-home-design-rules
description: "Design direction the user set for the Luma take-home UI (Impeccable work, Sept 2026): no prices on triggers, no names, dot-not-badge states, pushback expected"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d23e6400-285f-46e8-8872-f99eca4837ea
  modified: 2026-09-05T16:48:41.028Z
---

Design rules the user set during the Impeccable rounds (2026-09-05), recorded in
`docs/superpowers/plans/2026-09-05-shared-visual-system.md` and DECISIONS D20/D21:

- No dollar estimate on any generation trigger; the caps in `enqueue` are the bound (D20).
- No person's name anywhere in UI copy or code defaults (bylines "Approved · 4 Sep").
- State labels are a coloured dot beside neutral text, never a tinted badge with same-hue
  text ("green on green is an AI tell"). Hues are theme tokens moss / clay / ochre, not
  Tailwind green / red / amber. `STATUS_TONE` uses meaning names (wait / ok / stop / neutral).
- lucide-react icons, 20 px, strokeWidth 1.75; native `<details>` and popover, no JS for UI.
- Never show HTTP status codes or technical detail to the team; `friendlyFailure()`.
- Follow-up actions (Try again, Generate more) hidden behind a More menu during review,
  surfaced on the end card when they are the next step; Generate more stays on Done products.

**Why:** the brief's ask is a bound on spend, not a receipt per tap; the abandoned dashboard
is the anti-reference; the user wants craft that does not read as generated.

**How to apply:** when touching either page, reuse `Dot`, `STATUS_TONE`, `PRIMARY`/`QUIET`
from `app/review/[sku]/page.tsx`; run `/impeccable critique` before proposing, present
options with trade-offs, and push back where a suggestion conflicts with the contract.
The user explicitly asks for pushback on their own suggestions and reads the reasoning.
Related: [[luma-take-home-working-style]], [[luma-take-home-resume]].

- **Name (2026-09-06, D30):** the app is **Dropshot**, one word, chosen by the user over Contact Sheet / Proofs / Picks. The constant and the mark live in `components/Logo.tsx`; favicon is `app/icon.svg`, exempted in the middleware matcher.
